package com.hy300.launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root;
    private LinearLayout appGrid;
    private static final int PICK_WALLPAPER = 41;
    private final int panelColor = Color.argb(190, 12, 15, 25);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildScreen();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildScreen() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(13, 18, 29));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setPadding(dp(28), dp(24), dp(12), dp(20));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            getResources().getDisplayMetrics().widthPixels - dp(310),
            FrameLayout.LayoutParams.MATCH_PARENT, Gravity.LEFT);
        root.addView(left, lp);

        TextView brand = new TextView(this);
        brand.setText("HY300");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(16);
        brand.setLetterSpacing(0.18f);
        left.addView(brand);

        TextView clock = new TextView(this);
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(48);
        clock.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(22);
        left.addView(clock, cp);
        TextView date = new TextView(this);
        date.setTextColor(0xFFCFD5E2);
        date.setTextSize(16);
        left.addView(date);
        updateClock(clock, date);

        TextView hint = new TextView(this);
        hint.setText("Pilih aplikasi dari panel sebelah kanan");
        hint.setTextColor(0xFFB9C2D2);
        hint.setTextSize(15);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(28);
        left.addView(hint, hp);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(20);
        left.addView(buttons, bp);
        addActionButton(buttons, "Ganti wallpaper", v -> chooseWallpaper());
        addActionButton(buttons, "Muat ulang aplikasi", v -> populateApps());

        TextView footer = new TextView(this);
        footer.setText("Launcher layar besar • Navigasi remote D-pad");
        footer.setTextColor(0xFF8792A5);
        footer.setTextSize(12);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(18);
        left.addView(footer, fp);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(18), dp(16), dp(12));
        panel.setBackground(roundRect(panelColor, dp(22)));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(292), -1, Gravity.RIGHT);
        pp.setMargins(0, dp(12), dp(12), dp(12));
        root.addView(panel, pp);

        TextView title = new TextView(this);
        title.setText("APLIKASI");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        title.setTypeface(null, Typeface.BOLD);
        panel.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Pilih untuk membuka");
        subtitle.setTextColor(0xFFB5C0D0);
        subtitle.setTextSize(12);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(3);
        panel.addView(subtitle, sp);

        appGrid = new LinearLayout(this);
        appGrid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, 0, 1);
        gp.topMargin = dp(14);
        panel.addView(appGrid, gp);

        TextView weather = new TextView(this);
        weather.setText("CUACA  •  Atur kota melalui fitur cuaca versi berikutnya");
        weather.setTextColor(0xFFDCE4F1);
        weather.setTextSize(11);
        weather.setPadding(dp(10), dp(10), dp(10), dp(10));
        weather.setBackground(roundRect(0x553B4960, dp(12)));
        panel.addView(weather);

        setContentView(root);
        populateApps();
    }

    private void updateClock(TextView clock, TextView date) {
        java.text.SimpleDateFormat tf = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());
        java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("EEEE, d MMMM yyyy", java.util.Locale.getDefault());
        Runnable r = new Runnable() {
            public void run() {
                Date now = new Date();
                clock.setText(tf.format(now));
                date.setText(df.format(now));
                clock.postDelayed(this, 30000);
            }
        };
        r.run();
    }

    private GradientDrawable roundRect(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private void addActionButton(LinearLayout row, String text, View.OnClickListener click) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setFocusable(true);
        b.setPadding(dp(14), dp(11), dp(14), dp(11));
        b.setBackground(roundRect(0xAA27364B, dp(12)));
        b.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.rightMargin = dp(10);
        row.addView(b, p);
    }

    private void chooseWallpaper() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, PICK_WALLPAPER);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_WALLPAPER && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            try {
                root.setBackground(Drawable.createFromStream(getContentResolver().openInputStream(uri), null));
            } catch (Exception e) {
                Toast.makeText(this, "Foto tidak bisa dibuka", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void populateApps() {
        if (appGrid == null) return;
        appGrid.removeAllViews();
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        Collections.sort(apps, (a,b) -> String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        int max = Math.min(apps.size(), 28);
        for (int i = 0; i < max; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            appGrid.addView(row, new LinearLayout.LayoutParams(-1, 0, 1));
            addAppTile(row, apps.get(i));
            if (i + 1 < max) addAppTile(row, apps.get(i + 1));
        }
        if (apps.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Belum ada aplikasi yang terdeteksi");
            empty.setTextColor(Color.WHITE);
            appGrid.addView(empty);
        }
    }

    private void addAppTile(LinearLayout row, ResolveInfo info) {
        PackageManager pm = getPackageManager();
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setFocusable(true);
        tile.setClickable(true);
        tile.setBackground(roundRect(0x553A465A, dp(14)));
        tile.setPadding(dp(4), dp(5), dp(4), dp(5));
        ImageView icon = new ImageView(this);
        try { icon.setImageDrawable(info.loadIcon(pm)); } catch (Exception ignored) {}
        tile.addView(icon, new LinearLayout.LayoutParams(dp(34), dp(34)));
        TextView label = new TextView(this);
        label.setText(info.loadLabel(pm));
        label.setTextColor(Color.WHITE);
        label.setTextSize(11);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(5);
        tile.addView(label, tp);
        tile.setOnClickListener(v -> {
            try {
                Intent launch = pm.getLaunchIntentForPackage(info.activityInfo.packageName);
                if (launch != null) startActivity(launch);
                else Toast.makeText(this, "Aplikasi tidak bisa dibuka dari launcher", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Tidak bisa membuka aplikasi", Toast.LENGTH_SHORT).show();
            }
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1);
        p.setMargins(dp(4), dp(3), dp(4), dp(3));
        row.addView(tile, p);
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            chooseWallpaper();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
