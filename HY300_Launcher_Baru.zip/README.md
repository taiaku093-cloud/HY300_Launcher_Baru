# HY300 Launcher (source project)

This is an Android launcher starter project designed for landscape projectors and Android TV boxes.

## Included
- Landscape home screen
- Large clock and date
- Right-side translucent panel
- Automatically lists installed launcher apps in two columns
- Opens apps with remote/keyboard selection or touch
- Choose a photo as wallpaper
- HOME, LAUNCHER and LEANBACK launcher intent categories

## Build
Use Android Studio (JDK 17, Android SDK 35, Gradle 8.9) or the included GitHub Actions workflow.
The workflow builds `app/build/outputs/apk/debug/app-debug.apk` and uploads it as an artifact.

## Important compatibility note
This project targets Android 5.0+ (minSdk 21), but actual HOME-launcher behavior depends on the projector/TV box firmware. Test on the device and select "HY300 Launcher" as the Home app when Android asks. Some devices restrict third-party launchers.

This is source code, not a prebuilt APK. A successful build must produce `app-debug.apk`.
Weather and live TV are not implemented in this starter; the weather strip is a placeholder.
